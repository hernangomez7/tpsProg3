<?php

    include_once ".\\clases\\AccesoDatos.php";
    include_once ".\\clases\\usuario.php";
    

    if(isset($_POST["opcion"]) && !empty($_POST["opcion"]))
    {     
        $caso = $_POST["opcion"];
        switch($caso)
        {
            case "Mostrar":
                $unusuario = new usuario();
                $unusuario->MostarTodos();
            break;
            case "Insertar":
                if(isset($_POST["titulo"]) && !empty($_POST["titulo"]))
                {
                    if(isset($_POST["cantante"]) && !empty($_POST["cantante"]))
                    {
                        if(isset($_POST["año"]) && !empty($_POST["año"]))
                        {
                            $unusuario = new usuario();
                            $unusuario->Guardarusuario( $_POST["titulo"], $_POST["cantante"], $_POST["año"] );
                            echo "adicion completada";
                        }
                    }
                }  
            break;


            case "borrarId":
                if(isset($_POST["id"]) && !empty($_POST["id"]))
                {
                    $unusuario = new usuario();
                    $unusuario->BorrarPorId( $_POST["id"] );
                }
                else
                {
                    echo "falta id";
                }
            break;

            case "modificar":
                if(isset($_POST["id"]) && !empty($_POST["id"]))
                {
                    if(isset($_POST["titulo"]) && !empty($_POST["titulo"]))
                    {
                        if(isset($_POST["cantante"]) && !empty($_POST["cantante"]))
                        {
                            if(isset($_POST["año"]) && !empty($_POST["año"]))
                            {
                                $unusuario = new usuario();
                                $unusuario->Modificar($_POST["titulo"], $_POST["cantante"], $_POST["año"] ,$_POST["id"]);
                            }
                        }
                    }
                    $unusuario = new usuario();
                    $unusuario->BuscarPorId( $_POST["id"] );               
                }
                else
                {
                    echo "faltan id";
                }
            break;

                //trabajo practico en github tp-progarmacion31c2018 tp_
                //la comanda es cambiar el estado
                //el cliente pide algo y se da el alta
                //lo agarra el moso y lo cambia "en camino"
                //el cocinero lo cambia a cocinando...listo para entregar...entregado
        }

    }




?>