<?php


class Usuario
{
    public $nombre='';
    public $clave='';

    function Constructor($nombre, $clave)
    {
       $this->nombre=$nombre;
       $this->clave=$clave;
    }

    function ToString()
    {
        $myUsuario="$this->nombre"."  "."$this->clave";
        return $myUsuario;
    }

    public function ToJson($ruta, $usuario)
    {
        $contArchivo = file_get_contents($ruta);
        $milista = json_decode($contArchivo);
        if(is_null($milista))
        {
         $milista = array($usuario);
        }
        else
        {
         array_push($milista, $usuario);
        }
        return json_encode($milista);
    }
}

?>