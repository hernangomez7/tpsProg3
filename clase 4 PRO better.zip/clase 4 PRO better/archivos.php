<?php

	include ".\\Clases\\Usuarios.php";

	$nombre=$_POST['nombre'];
	$clave=$_POST['clave'];
	$usuario= new Usuario;
	
	
	$usuario->Constructor($nombre, $clave);
	
	
	echo $usuario->ToString();
	
	if(!(file_exists (".\\Datos\\Datos.json")))
	{
		mkdir(".\\Datos");
		$fichero=fopen ( ".\\Datos\\Datos.json" , "w");
		fclose($fichero);
	}
	else
	{
		$contArchivo = file_get_contents(".\\Datos\\Datos.json");
		$milista = json_decode($contArchivo);
		echo $milista[0]->ToString();
	}

	$aGuardar = $usuario->ToJson(".\\Datos\\Datos.json", $usuario);

	$fichero=fopen ( ".\\Datos\\Datos.json" , "w+");
	fwrite($fichero, $aGuardar );
	fclose($fichero);
	
	/*
	if(file_exists (".\\Datos\\Datos.json"))
	{
		$fichero=fopen ( ".\\Datos\\Datos.json" , "w+");
		fwrite($fichero, $usuario->ToJson(".\\Datos\\Datos.json", $usuario));
		fclose($fichero);
	}
	else
	{
		mkdir(".\\Datos");
		$fichero=fopen ( ".\\Datos\\Datos.json" , "w+");
		fwrite($fichero, $usuario->ToJson(".\\Datos\\Datos.json", $usuario));
		fclose($fichero);
	}*/

?>